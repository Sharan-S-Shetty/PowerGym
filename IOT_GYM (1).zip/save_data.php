<?php
// Database connection details
$servername = "localhost";
$username = "u563041017_iotApp";
$password = "iotApp@123";
$dbname = "u563041017_iotApp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the POST request sent by NodeMCU
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sensor1 = $_POST["sensor1"];
    $sensor2 = $_POST["sensor2"];
    $sensor3 = $_POST["sensor3"];

    // Insert data into the table
    $sql = "INSERT INTO `iot_gym` (sensor1, sensor2, sensor3) 
            VALUES ('$sensor1', '$sensor2', '$sensor3')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>